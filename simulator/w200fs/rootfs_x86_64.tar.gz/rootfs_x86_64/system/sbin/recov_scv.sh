#!/bin/bash

/system/sbin/pwrd 10 10 &
/system/sbin/webdm -breakdown &
